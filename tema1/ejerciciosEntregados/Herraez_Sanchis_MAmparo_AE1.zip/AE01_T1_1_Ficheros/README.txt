2ºDAM_AAD
AE01_T1_ficheros
Maria Amparo Herráez Sanchis
30/09/2021

Utilización de la clase File de Java.
Se va a obtener información del directorio de trabajo, se creará una carpeta y un fichero, luego se eliminará el fichero y finalmente se renombrará la carpeta.

@param .\documentacion
-métodos utilizados:
getInformacion
creaCarpeta
creaFichero
elimina
renombra